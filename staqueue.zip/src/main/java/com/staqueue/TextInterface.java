package com.staqueue;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DELL
 */
//Interface used to pass messages relevant to the operations performed to the Frame class 
public interface TextInterface {

    public void setText(String str);
}
